﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex3Calculadora
{
    class Calculadora
    {
        delegate int Calculo(int a, int b);
    }
}
